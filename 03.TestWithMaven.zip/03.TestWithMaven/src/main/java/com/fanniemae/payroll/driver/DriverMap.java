package com.fanniemae.payroll.driver;

import java.util.HashMap;
import java.util.Set;

public class DriverMap {

	public static void main(String[] args) {

		HashMap<String, Double> map = new HashMap<>();

		map.put("david", 1000000d);
		map.put("lucy", 2000000d);
		map.put("peter", 3000000d);

		System.out.println(map.get("david"));
		System.out.println(map.size());

		Set<String> keys = map.keySet();

		for (String string : keys) {
			System.out.println(string.toUpperCase());
		}

	}
}
